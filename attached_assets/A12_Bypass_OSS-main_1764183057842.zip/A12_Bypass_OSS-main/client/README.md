# Client Setup

1. Ensure you have `libimobiledevice` and `pymobiledevice3` installed.
2. Open `activator.py` in a text editor.
3. Locate line 20: `self.api_url = "https://your-domain.com/index.php"`
4. Change `your-domain.com` to the actual URL where you deployed the server folder.
5. Run: `python3 activator.py`
